const express = require('express');
const fs = require('fs');
const app = express();
const cors = require('cors')
const port = 3000;


app.use(cors({
    origin: '*'
}))
app.use(express.json());

// Read groups from file
function readGroups() {
    const data = fs.readFileSync('groups.json');
    return JSON.parse(data);
}

// Write groups to file
function writeGroups(groups) {
    const data = JSON.stringify(groups);
    fs.writeFileSync('groups.json', data);
}

// Get all groups
app.get('/groups', (req, res) => {
    const groups = readGroups();
    res.json(groups);
});

// Create a new group
app.post('/groups', (req, res) => {
    const { category, groupName } = req.body;
    const groups = readGroups();
    const group = { category, groupName };
    groups.groupsData.push(group);
    writeGroups(groups);
    res.json(group);
});
// Delete a single group
app.delete('/groups/:groupID', (req, res) => {
    const { groupID } = req.params;
    const { groupName } = req.body;
    const groups = readGroups();
    const groupIndex = groups.groupsData.findIndex(group => group.groupName === groupName);
    groups.groupsData.splice(groupIndex, 1);
    writeGroups(groups);
    res.json(groupID);
});
// Download groups as a file
app.get('/download', (req, res) => {
    const groups = readGroups();
    const data = JSON.stringify(groups, null, 2);
    res.setHeader('Content-Disposition', 'attachment; filename="groups.json"');
    res.setHeader('Content-Type', 'application/json');
    res.send(data);
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
