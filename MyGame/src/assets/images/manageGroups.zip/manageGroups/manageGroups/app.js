const groupsPerPage = 50; // Number of groups to display per page
const addButtonSAC = document.getElementById('addButtonSAC')
const addButtonAll = document.getElementById('addButtonAll')
const searchSAC = document.getElementById('SACGroupFilter')
const searchAll = document.getElementById('AllGroupFilter')
const inputSAC = document.getElementById('SACGroupInput')
const inputAll = document.getElementById('AllGroupInput')


// Fetch and display groups based on filter and pagination
async function fetchGroups(category, filter, page) {
    const response = await fetch(`http://localhost:3000/groups?category=${category}`);
    if (response.ok) {
        const groups = await response.json();

        let filteredGroups = groups.groupsData
        // Apply filter
        if(filter) {
            filteredGroups = groups.groupsData.filter(group => group.groupName.toLowerCase().includes(filter.toLowerCase()));
        }
        // Calculate pagination parameters
        const startIndex = (page - 1) * groupsPerPage;
        const endIndex = startIndex + groupsPerPage;
        const paginatedGroups = filteredGroups.slice(startIndex, endIndex);

        // Update UI
        const list = document.getElementById(`${category}List`);
        const pagination = document.getElementById(`${category}Pagination`);


        list.innerHTML = '';
        for (const group of paginatedGroups) {
            if(group.category === category) {
                const listItem = document.createElement('li');
                const deleteButton = document.createElement('button');
                let groupID = group.category
                let groupName = group.groupName
                listItem.id = group.groupName;
                deleteButton.id = group.groupName + 'button';
                deleteButton.textContent = 'X';
                deleteButton.addEventListener("click", function() {
                    deleteGroup(groupID, groupName)
                })
                listItem.textContent = group.groupName;
                list.appendChild(listItem);
                listItem.appendChild(deleteButton);
            }
        }

        // Update pagination links
        const totalPages = Math.ceil(filteredGroups.length / groupsPerPage);
        // pagination.innerHTML = '';
        for (let i = 1; i <= totalPages; i++) {
            const link = document.createElement('a');
            link.href = '#';
            link.textContent = i;
            if (i === page) {
                link.classList.add('active');
            } else {
                link.addEventListener('click', () => {
                    fetchGroups(category, filter, i);
                });
            }
            // pagination.appendChild(link);
        }
    }
}
// Send a POST request to create a new group
async function addGroup(category) {
    const input = document.getElementById(`${category}Input`);
    const groupName = input.value;

    if(groupName.length < 1)
        return false

    input.value = '';


    const response = await fetch(`http://localhost:3000/groups`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ category, groupName })
    });

    if (response.ok) {
        const filterInput = document.getElementById(`${category}Filter`);
        const page = 1; // Reset pagination to first page
        await fetchGroups(category, filterInput.value, page);
    }
}

//Delete group
async function deleteGroup(groupID,groupName) {
    const response = await fetch(`http://localhost:3000/groups/${groupID}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ groupName })
    });
    console.log(response)
    if (response.ok) {
        const categories = ['SACGroup', 'AllGroup'];
        for (const category of categories) {
            const filterInput = document.getElementById(`${category}Filter`);
            const page = 1; // Start from the first page
            await fetchGroups(category, false, page);
            filterInput.addEventListener('input', () => {
                handleFilterChange(category);
            });
        }
    }
}

// Apply filter when user types in the filter input
function handleFilterChange(category) {
    const filterInput = document.getElementById(`${category}Filter`);
    const page = 1; // Reset pagination to first page
    fetchGroups(category, filterInput.value, page);
}





addButtonSAC.addEventListener('click',() => {addGroup('SACGroup')})
addButtonAll.addEventListener('click', ()  => {addGroup('AllGroup')})
inputSAC.addEventListener('keydown',(key) => {
    if(key.key === 'Enter') {
        addGroup('SACGroup')
    }
})
inputAll.addEventListener('keydown',(key) => {
    if(key.key === 'Enter') {
        addGroup('AllGroup')
    }
})


// Fetch the existing groups on page load
window.addEventListener('load', async () => {
    const categories = ['SACGroup', 'AllGroup'];
    for (const category of categories) {
        const filterInput = document.getElementById(`${category}Filter`);
        const page = 1; // Start from the first page
        await fetchGroups(category, false, page);
        filterInput.addEventListener('input', () => {
            handleFilterChange(category);
        });
    }
});

fetchGroups('SACGroup', '', 1)
fetchGroups('AllGroup', '', 1)
